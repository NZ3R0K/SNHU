/*
Name		: Nathan Hallam
Course		: IT-132
Date		: 21st April, 2024
Project NO	: 7.1
File Name	: FarkleMain.cpp
Description : Nothing special here, just the main call for the entire program.
*/

#include "Player.h"
#include "FarkleCore.h"

int main() {
	FarkleCore Game;

	Game.CoreLoop();
}