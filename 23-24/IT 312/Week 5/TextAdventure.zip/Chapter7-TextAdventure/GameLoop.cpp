#include "GameLoop.h"
#include <iostream>

using namespace std;

void Game::Welcome()
{
	cout << "Welcome to Text Game!" << endl << endl;
	cout << "What is your name?" << endl << endl;

	string name;
	cin >> name;
	m_player.SetName(name);

	cout << endl << "Hello " << m_player.GetName() << endl;
}

void Game::GivePlayerChoices() const
{
	cout << "Enter a number" << endl << endl;
	cout << "1: Quit" << endl << endl;
}

void Game::GetPlayerInput(string& playerInput) const
{
	cin >> playerInput;
}

PlayerOptions Game::EvaluateInput(string& playerInput) const
{
	PlayerOptions chosenOption = PlayerOptions::None;

	if (playerInput.compare("1") == 0)
	{
		cout << "You have chosen to Quit!" << endl << endl;
		chosenOption = PlayerOptions::Quit;
	}
	else
	{
		cout << "Try again!" << endl << endl;
	}

	return chosenOption;
}

void Game::RunGame()
{
	Welcome();

	bool shouldEnd = false;
	while (shouldEnd == false)
	{
		GivePlayerChoices();

		string playerInput;
		GetPlayerInput(playerInput);

		shouldEnd = EvaluateInput(playerInput) == PlayerOptions::Quit;
	}
}