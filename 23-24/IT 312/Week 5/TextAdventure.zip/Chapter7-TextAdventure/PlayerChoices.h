#pragma once

enum class PlayerOptions
{
	Quit,
	None
};