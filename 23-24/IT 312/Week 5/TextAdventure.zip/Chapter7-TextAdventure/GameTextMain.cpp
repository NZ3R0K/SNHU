// GameTextMain.cpp : Defines the entry point for the console application.
//


#include "Player.h"
#include "GameLoop.h"

int main()
{
	Game game;
	game.RunGame();

	return 0;
}