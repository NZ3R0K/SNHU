﻿class Program
{
	// Initialize global integer array with preset values
	// Readonly to prevent accidentally changing values during runtime
	static readonly int[] integers = { 13, 55, 123, 325 };


	static void Main()
	{
		Console.WriteLine("Hallam Copy");

		PrintMath();

		// Pause build
		Console.WriteLine("Press any key to continue . . .");
		Console.ReadKey();
	}


	// Print math output to console
	static void PrintMath()
	{
		Console.WriteLine($"The sum of 13, 55, 123, and 325 = {SumOfInts()}");
		Console.WriteLine($"The product of 13, 55, 123, and 325 = {ProductOfInts()}");
	}


	// Add integers together
	static int SumOfInts()
	{
		int total = 0;

		foreach (int i in integers)
			total += i;

		return total;
	}


	// Get the product of the integers
	static int ProductOfInts()
	{
		int total = 1;

		foreach(int i in integers) 
			total *= i;

		return total;
	}
}