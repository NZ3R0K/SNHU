﻿class Program
{
	static void Main()
	{
		Console.WriteLine
		(
			"Hallam" +
			"\nHello World!" +
			"\nPress any key to continue..."
		);

		Console.ReadKey();
	}
}